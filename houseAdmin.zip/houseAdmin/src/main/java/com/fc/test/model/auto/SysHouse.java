package com.fc.test.model.auto;

import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.lang.Integer;

/**
 *  SysHouse 
 * @author wcy_自动生成
 * @email xxx@qq.com
 * @date 2020-03-16 20:42:26
 */
 @ApiModel(value="SysHouse", description="")
public class SysHouse implements Serializable {

	private static final long serialVersionUID = 1L;
	
		
	/**  **/
	@ApiModelProperty(value = "")
	private Integer id;
		
	/** 租房描述 **/
	@ApiModelProperty(value = "租房描述")
	private String houseDesc;
		
	/** 房屋类型，几室几厅 **/
	@ApiModelProperty(value = "房屋类型，几室几厅")
	private String houseModel;
		
	/** 房屋面积 **/
	@ApiModelProperty(value = "房屋面积")
	private String houseArea;
		
	/** 房屋楼层 **/
	@ApiModelProperty(value = "房屋楼层")
	private String houseFloor;
		
	/** 出租方式 **/
	@ApiModelProperty(value = "出租方式")
	private String houseType;
		
	/** 出租价格 **/
	@ApiModelProperty(value = "出租价格")
	private Integer housePrice;
		
	/** 出租地址 **/
	@ApiModelProperty(value = "出租地址")
	private String houseAddress;
		
	/** 房屋简介照片 **/
	@ApiModelProperty(value = "房屋简介照片")
	private String houseImage;
		
	/** 小区名字 **/
	@ApiModelProperty(value = "小区名字")
	private String communityName;
		
	/** 房屋联系电话 **/
	@ApiModelProperty(value = "房屋联系电话")
	private String houseLinkman;
		
	/** 房屋朝向 **/
	@ApiModelProperty(value = "房屋朝向")
	private String houseOriented;
		
	/** 房屋详细页面展示图片 **/
	@ApiModelProperty(value = "房屋详细页面展示图片")
	private String houseDetailesImg;
		
	/** 发布人 **/
	@ApiModelProperty(value = "发布人")
	private String publisher;
		
	/** 发布时间 **/
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
	@ApiModelProperty(value = "发布时间")
	private Date publishTime;
		
	/**  **/
	@ApiModelProperty(value = "")
	private Integer userId;
		
	/**  **/
	@ApiModelProperty(value = "")
	private Integer status;
		
	/**  **/
	@ApiModelProperty(value = "")
	private String statusStr;
		
		
	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
	 
			
	public String getHouseDesc() {
        return houseDesc;
    }

    public void setHouseDesc(String houseDesc) {
        this.houseDesc = houseDesc;
    }
	 
			
	public String getHouseModel() {
        return houseModel;
    }

    public void setHouseModel(String houseModel) {
        this.houseModel = houseModel;
    }
	 
			
	public String getHouseArea() {
        return houseArea;
    }

    public void setHouseArea(String houseArea) {
        this.houseArea = houseArea;
    }
	 
			
	public String getHouseFloor() {
        return houseFloor;
    }

    public void setHouseFloor(String houseFloor) {
        this.houseFloor = houseFloor;
    }
	 
			
	public String getHouseType() {
        return houseType;
    }

    public void setHouseType(String houseType) {
        this.houseType = houseType;
    }
	 
			
	public Integer getHousePrice() {
        return housePrice;
    }

    public void setHousePrice(Integer housePrice) {
        this.housePrice = housePrice;
    }
	 
			
	public String getHouseAddress() {
        return houseAddress;
    }

    public void setHouseAddress(String houseAddress) {
        this.houseAddress = houseAddress;
    }
	 
			
	public String getHouseImage() {
        return houseImage;
    }

    public void setHouseImage(String houseImage) {
        this.houseImage = houseImage;
    }
	 
			
	public String getCommunityName() {
        return communityName;
    }

    public void setCommunityName(String communityName) {
        this.communityName = communityName;
    }
	 
			
	public String getHouseLinkman() {
        return houseLinkman;
    }

    public void setHouseLinkman(String houseLinkman) {
        this.houseLinkman = houseLinkman;
    }
	 
			
	public String getHouseOriented() {
        return houseOriented;
    }

    public void setHouseOriented(String houseOriented) {
        this.houseOriented = houseOriented;
    }
	 
			
	public String getHouseDetailesImg() {
        return houseDetailesImg;
    }

    public void setHouseDetailesImg(String houseDetailesImg) {
        this.houseDetailesImg = houseDetailesImg;
    }
	 
			
	public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }
	 
			
	public Date getPublishTime() {
        return publishTime;
    }

    public void setPublishTime(Date publishTime) {
        this.publishTime = publishTime;
    }
	 
			
	public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }
	 
			
	public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
	 
			
	public String getStatusStr() {
        return statusStr;
    }

    public void setStatusStr(String statusStr) {
        this.statusStr = statusStr;
    }
	 
			
	public SysHouse() {
        super();
    }
    
																																																																																												
	public SysHouse(Integer id,String houseDesc,String houseModel,String houseArea,String houseFloor,String houseType,Integer housePrice,String houseAddress,String houseImage,String communityName,String houseLinkman,String houseOriented,String houseDetailesImg,String publisher,Date publishTime,Integer userId,Integer status,String statusStr) {
	
		this.id = id;
		this.houseDesc = houseDesc;
		this.houseModel = houseModel;
		this.houseArea = houseArea;
		this.houseFloor = houseFloor;
		this.houseType = houseType;
		this.housePrice = housePrice;
		this.houseAddress = houseAddress;
		this.houseImage = houseImage;
		this.communityName = communityName;
		this.houseLinkman = houseLinkman;
		this.houseOriented = houseOriented;
		this.houseDetailesImg = houseDetailesImg;
		this.publisher = publisher;
		this.publishTime = publishTime;
		this.userId = userId;
		this.status = status;
		this.statusStr = statusStr;
		
	}
	
}