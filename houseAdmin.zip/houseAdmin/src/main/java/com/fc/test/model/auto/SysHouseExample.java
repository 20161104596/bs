package com.fc.test.model.auto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *  SysHouseExample
 * @author wcy_自动生成
 * @email xxx@qq.com
 * @date 2020-03-16 20:42:26
 */
public class SysHouseExample {

    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public SysHouseExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }
				
        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLike(Integer value) {
            addCriterion("id like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotLike(Integer value) {
            addCriterion("id not like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }
        
			
        public Criteria andHouseDescIsNull() {
            addCriterion("house_desc is null");
            return (Criteria) this;
        }

        public Criteria andHouseDescIsNotNull() {
            addCriterion("house_desc is not null");
            return (Criteria) this;
        }

        public Criteria andHouseDescEqualTo(String value) {
            addCriterion("house_desc =", value, "houseDesc");
            return (Criteria) this;
        }

        public Criteria andHouseDescNotEqualTo(String value) {
            addCriterion("house_desc <>", value, "houseDesc");
            return (Criteria) this;
        }

        public Criteria andHouseDescGreaterThan(String value) {
            addCriterion("house_desc >", value, "houseDesc");
            return (Criteria) this;
        }

        public Criteria andHouseDescGreaterThanOrEqualTo(String value) {
            addCriterion("house_desc >=", value, "houseDesc");
            return (Criteria) this;
        }

        public Criteria andHouseDescLessThan(String value) {
            addCriterion("house_desc <", value, "houseDesc");
            return (Criteria) this;
        }

        public Criteria andHouseDescLessThanOrEqualTo(String value) {
            addCriterion("house_desc <=", value, "houseDesc");
            return (Criteria) this;
        }

        public Criteria andHouseDescLike(String value) {
            addCriterion("house_desc like", value, "houseDesc");
            return (Criteria) this;
        }

        public Criteria andHouseDescNotLike(String value) {
            addCriterion("house_desc not like", value, "houseDesc");
            return (Criteria) this;
        }

        public Criteria andHouseDescIn(List<String> values) {
            addCriterion("house_desc in", values, "houseDesc");
            return (Criteria) this;
        }

        public Criteria andHouseDescNotIn(List<String> values) {
            addCriterion("house_desc not in", values, "houseDesc");
            return (Criteria) this;
        }

        public Criteria andHouseDescBetween(String value1, String value2) {
            addCriterion("house_desc between", value1, value2, "houseDesc");
            return (Criteria) this;
        }

        public Criteria andHouseDescNotBetween(String value1, String value2) {
            addCriterion("house_desc not between", value1, value2, "houseDesc");
            return (Criteria) this;
        }
        
			
        public Criteria andHouseModelIsNull() {
            addCriterion("house_model is null");
            return (Criteria) this;
        }

        public Criteria andHouseModelIsNotNull() {
            addCriterion("house_model is not null");
            return (Criteria) this;
        }

        public Criteria andHouseModelEqualTo(String value) {
            addCriterion("house_model =", value, "houseModel");
            return (Criteria) this;
        }

        public Criteria andHouseModelNotEqualTo(String value) {
            addCriterion("house_model <>", value, "houseModel");
            return (Criteria) this;
        }

        public Criteria andHouseModelGreaterThan(String value) {
            addCriterion("house_model >", value, "houseModel");
            return (Criteria) this;
        }

        public Criteria andHouseModelGreaterThanOrEqualTo(String value) {
            addCriterion("house_model >=", value, "houseModel");
            return (Criteria) this;
        }

        public Criteria andHouseModelLessThan(String value) {
            addCriterion("house_model <", value, "houseModel");
            return (Criteria) this;
        }

        public Criteria andHouseModelLessThanOrEqualTo(String value) {
            addCriterion("house_model <=", value, "houseModel");
            return (Criteria) this;
        }

        public Criteria andHouseModelLike(String value) {
            addCriterion("house_model like", value, "houseModel");
            return (Criteria) this;
        }

        public Criteria andHouseModelNotLike(String value) {
            addCriterion("house_model not like", value, "houseModel");
            return (Criteria) this;
        }

        public Criteria andHouseModelIn(List<String> values) {
            addCriterion("house_model in", values, "houseModel");
            return (Criteria) this;
        }

        public Criteria andHouseModelNotIn(List<String> values) {
            addCriterion("house_model not in", values, "houseModel");
            return (Criteria) this;
        }

        public Criteria andHouseModelBetween(String value1, String value2) {
            addCriterion("house_model between", value1, value2, "houseModel");
            return (Criteria) this;
        }

        public Criteria andHouseModelNotBetween(String value1, String value2) {
            addCriterion("house_model not between", value1, value2, "houseModel");
            return (Criteria) this;
        }
        
			
        public Criteria andHouseAreaIsNull() {
            addCriterion("house_area is null");
            return (Criteria) this;
        }

        public Criteria andHouseAreaIsNotNull() {
            addCriterion("house_area is not null");
            return (Criteria) this;
        }

        public Criteria andHouseAreaEqualTo(String value) {
            addCriterion("house_area =", value, "houseArea");
            return (Criteria) this;
        }

        public Criteria andHouseAreaNotEqualTo(String value) {
            addCriterion("house_area <>", value, "houseArea");
            return (Criteria) this;
        }

        public Criteria andHouseAreaGreaterThan(String value) {
            addCriterion("house_area >", value, "houseArea");
            return (Criteria) this;
        }

        public Criteria andHouseAreaGreaterThanOrEqualTo(String value) {
            addCriterion("house_area >=", value, "houseArea");
            return (Criteria) this;
        }

        public Criteria andHouseAreaLessThan(String value) {
            addCriterion("house_area <", value, "houseArea");
            return (Criteria) this;
        }

        public Criteria andHouseAreaLessThanOrEqualTo(String value) {
            addCriterion("house_area <=", value, "houseArea");
            return (Criteria) this;
        }

        public Criteria andHouseAreaLike(String value) {
            addCriterion("house_area like", value, "houseArea");
            return (Criteria) this;
        }

        public Criteria andHouseAreaNotLike(String value) {
            addCriterion("house_area not like", value, "houseArea");
            return (Criteria) this;
        }

        public Criteria andHouseAreaIn(List<String> values) {
            addCriterion("house_area in", values, "houseArea");
            return (Criteria) this;
        }

        public Criteria andHouseAreaNotIn(List<String> values) {
            addCriterion("house_area not in", values, "houseArea");
            return (Criteria) this;
        }

        public Criteria andHouseAreaBetween(String value1, String value2) {
            addCriterion("house_area between", value1, value2, "houseArea");
            return (Criteria) this;
        }

        public Criteria andHouseAreaNotBetween(String value1, String value2) {
            addCriterion("house_area not between", value1, value2, "houseArea");
            return (Criteria) this;
        }
        
			
        public Criteria andHouseFloorIsNull() {
            addCriterion("house_floor is null");
            return (Criteria) this;
        }

        public Criteria andHouseFloorIsNotNull() {
            addCriterion("house_floor is not null");
            return (Criteria) this;
        }

        public Criteria andHouseFloorEqualTo(String value) {
            addCriterion("house_floor =", value, "houseFloor");
            return (Criteria) this;
        }

        public Criteria andHouseFloorNotEqualTo(String value) {
            addCriterion("house_floor <>", value, "houseFloor");
            return (Criteria) this;
        }

        public Criteria andHouseFloorGreaterThan(String value) {
            addCriterion("house_floor >", value, "houseFloor");
            return (Criteria) this;
        }

        public Criteria andHouseFloorGreaterThanOrEqualTo(String value) {
            addCriterion("house_floor >=", value, "houseFloor");
            return (Criteria) this;
        }

        public Criteria andHouseFloorLessThan(String value) {
            addCriterion("house_floor <", value, "houseFloor");
            return (Criteria) this;
        }

        public Criteria andHouseFloorLessThanOrEqualTo(String value) {
            addCriterion("house_floor <=", value, "houseFloor");
            return (Criteria) this;
        }

        public Criteria andHouseFloorLike(String value) {
            addCriterion("house_floor like", value, "houseFloor");
            return (Criteria) this;
        }

        public Criteria andHouseFloorNotLike(String value) {
            addCriterion("house_floor not like", value, "houseFloor");
            return (Criteria) this;
        }

        public Criteria andHouseFloorIn(List<String> values) {
            addCriterion("house_floor in", values, "houseFloor");
            return (Criteria) this;
        }

        public Criteria andHouseFloorNotIn(List<String> values) {
            addCriterion("house_floor not in", values, "houseFloor");
            return (Criteria) this;
        }

        public Criteria andHouseFloorBetween(String value1, String value2) {
            addCriterion("house_floor between", value1, value2, "houseFloor");
            return (Criteria) this;
        }

        public Criteria andHouseFloorNotBetween(String value1, String value2) {
            addCriterion("house_floor not between", value1, value2, "houseFloor");
            return (Criteria) this;
        }
        
			
        public Criteria andHouseTypeIsNull() {
            addCriterion("house_type is null");
            return (Criteria) this;
        }

        public Criteria andHouseTypeIsNotNull() {
            addCriterion("house_type is not null");
            return (Criteria) this;
        }

        public Criteria andHouseTypeEqualTo(String value) {
            addCriterion("house_type =", value, "houseType");
            return (Criteria) this;
        }

        public Criteria andHouseTypeNotEqualTo(String value) {
            addCriterion("house_type <>", value, "houseType");
            return (Criteria) this;
        }

        public Criteria andHouseTypeGreaterThan(String value) {
            addCriterion("house_type >", value, "houseType");
            return (Criteria) this;
        }

        public Criteria andHouseTypeGreaterThanOrEqualTo(String value) {
            addCriterion("house_type >=", value, "houseType");
            return (Criteria) this;
        }

        public Criteria andHouseTypeLessThan(String value) {
            addCriterion("house_type <", value, "houseType");
            return (Criteria) this;
        }

        public Criteria andHouseTypeLessThanOrEqualTo(String value) {
            addCriterion("house_type <=", value, "houseType");
            return (Criteria) this;
        }

        public Criteria andHouseTypeLike(String value) {
            addCriterion("house_type like", value, "houseType");
            return (Criteria) this;
        }

        public Criteria andHouseTypeNotLike(String value) {
            addCriterion("house_type not like", value, "houseType");
            return (Criteria) this;
        }

        public Criteria andHouseTypeIn(List<String> values) {
            addCriterion("house_type in", values, "houseType");
            return (Criteria) this;
        }

        public Criteria andHouseTypeNotIn(List<String> values) {
            addCriterion("house_type not in", values, "houseType");
            return (Criteria) this;
        }

        public Criteria andHouseTypeBetween(String value1, String value2) {
            addCriterion("house_type between", value1, value2, "houseType");
            return (Criteria) this;
        }

        public Criteria andHouseTypeNotBetween(String value1, String value2) {
            addCriterion("house_type not between", value1, value2, "houseType");
            return (Criteria) this;
        }
        
			
        public Criteria andHousePriceIsNull() {
            addCriterion("house_price is null");
            return (Criteria) this;
        }

        public Criteria andHousePriceIsNotNull() {
            addCriterion("house_price is not null");
            return (Criteria) this;
        }

        public Criteria andHousePriceEqualTo(Integer value) {
            addCriterion("house_price =", value, "housePrice");
            return (Criteria) this;
        }

        public Criteria andHousePriceNotEqualTo(Integer value) {
            addCriterion("house_price <>", value, "housePrice");
            return (Criteria) this;
        }

        public Criteria andHousePriceGreaterThan(Integer value) {
            addCriterion("house_price >", value, "housePrice");
            return (Criteria) this;
        }

        public Criteria andHousePriceGreaterThanOrEqualTo(Integer value) {
            addCriterion("house_price >=", value, "housePrice");
            return (Criteria) this;
        }

        public Criteria andHousePriceLessThan(Integer value) {
            addCriterion("house_price <", value, "housePrice");
            return (Criteria) this;
        }

        public Criteria andHousePriceLessThanOrEqualTo(Integer value) {
            addCriterion("house_price <=", value, "housePrice");
            return (Criteria) this;
        }

        public Criteria andHousePriceLike(Integer value) {
            addCriterion("house_price like", value, "housePrice");
            return (Criteria) this;
        }

        public Criteria andHousePriceNotLike(Integer value) {
            addCriterion("house_price not like", value, "housePrice");
            return (Criteria) this;
        }

        public Criteria andHousePriceIn(List<Integer> values) {
            addCriterion("house_price in", values, "housePrice");
            return (Criteria) this;
        }

        public Criteria andHousePriceNotIn(List<Integer> values) {
            addCriterion("house_price not in", values, "housePrice");
            return (Criteria) this;
        }

        public Criteria andHousePriceBetween(Integer value1, Integer value2) {
            addCriterion("house_price between", value1, value2, "housePrice");
            return (Criteria) this;
        }

        public Criteria andHousePriceNotBetween(Integer value1, Integer value2) {
            addCriterion("house_price not between", value1, value2, "housePrice");
            return (Criteria) this;
        }
        
			
        public Criteria andHouseAddressIsNull() {
            addCriterion("house_address is null");
            return (Criteria) this;
        }

        public Criteria andHouseAddressIsNotNull() {
            addCriterion("house_address is not null");
            return (Criteria) this;
        }

        public Criteria andHouseAddressEqualTo(String value) {
            addCriterion("house_address =", value, "houseAddress");
            return (Criteria) this;
        }

        public Criteria andHouseAddressNotEqualTo(String value) {
            addCriterion("house_address <>", value, "houseAddress");
            return (Criteria) this;
        }

        public Criteria andHouseAddressGreaterThan(String value) {
            addCriterion("house_address >", value, "houseAddress");
            return (Criteria) this;
        }

        public Criteria andHouseAddressGreaterThanOrEqualTo(String value) {
            addCriterion("house_address >=", value, "houseAddress");
            return (Criteria) this;
        }

        public Criteria andHouseAddressLessThan(String value) {
            addCriterion("house_address <", value, "houseAddress");
            return (Criteria) this;
        }

        public Criteria andHouseAddressLessThanOrEqualTo(String value) {
            addCriterion("house_address <=", value, "houseAddress");
            return (Criteria) this;
        }

        public Criteria andHouseAddressLike(String value) {
            addCriterion("house_address like", value, "houseAddress");
            return (Criteria) this;
        }

        public Criteria andHouseAddressNotLike(String value) {
            addCriterion("house_address not like", value, "houseAddress");
            return (Criteria) this;
        }

        public Criteria andHouseAddressIn(List<String> values) {
            addCriterion("house_address in", values, "houseAddress");
            return (Criteria) this;
        }

        public Criteria andHouseAddressNotIn(List<String> values) {
            addCriterion("house_address not in", values, "houseAddress");
            return (Criteria) this;
        }

        public Criteria andHouseAddressBetween(String value1, String value2) {
            addCriterion("house_address between", value1, value2, "houseAddress");
            return (Criteria) this;
        }

        public Criteria andHouseAddressNotBetween(String value1, String value2) {
            addCriterion("house_address not between", value1, value2, "houseAddress");
            return (Criteria) this;
        }
        
			
        public Criteria andHouseImageIsNull() {
            addCriterion("house_image is null");
            return (Criteria) this;
        }

        public Criteria andHouseImageIsNotNull() {
            addCriterion("house_image is not null");
            return (Criteria) this;
        }

        public Criteria andHouseImageEqualTo(String value) {
            addCriterion("house_image =", value, "houseImage");
            return (Criteria) this;
        }

        public Criteria andHouseImageNotEqualTo(String value) {
            addCriterion("house_image <>", value, "houseImage");
            return (Criteria) this;
        }

        public Criteria andHouseImageGreaterThan(String value) {
            addCriterion("house_image >", value, "houseImage");
            return (Criteria) this;
        }

        public Criteria andHouseImageGreaterThanOrEqualTo(String value) {
            addCriterion("house_image >=", value, "houseImage");
            return (Criteria) this;
        }

        public Criteria andHouseImageLessThan(String value) {
            addCriterion("house_image <", value, "houseImage");
            return (Criteria) this;
        }

        public Criteria andHouseImageLessThanOrEqualTo(String value) {
            addCriterion("house_image <=", value, "houseImage");
            return (Criteria) this;
        }

        public Criteria andHouseImageLike(String value) {
            addCriterion("house_image like", value, "houseImage");
            return (Criteria) this;
        }

        public Criteria andHouseImageNotLike(String value) {
            addCriterion("house_image not like", value, "houseImage");
            return (Criteria) this;
        }

        public Criteria andHouseImageIn(List<String> values) {
            addCriterion("house_image in", values, "houseImage");
            return (Criteria) this;
        }

        public Criteria andHouseImageNotIn(List<String> values) {
            addCriterion("house_image not in", values, "houseImage");
            return (Criteria) this;
        }

        public Criteria andHouseImageBetween(String value1, String value2) {
            addCriterion("house_image between", value1, value2, "houseImage");
            return (Criteria) this;
        }

        public Criteria andHouseImageNotBetween(String value1, String value2) {
            addCriterion("house_image not between", value1, value2, "houseImage");
            return (Criteria) this;
        }
        
			
        public Criteria andCommunityNameIsNull() {
            addCriterion("community_name is null");
            return (Criteria) this;
        }

        public Criteria andCommunityNameIsNotNull() {
            addCriterion("community_name is not null");
            return (Criteria) this;
        }

        public Criteria andCommunityNameEqualTo(String value) {
            addCriterion("community_name =", value, "communityName");
            return (Criteria) this;
        }

        public Criteria andCommunityNameNotEqualTo(String value) {
            addCriterion("community_name <>", value, "communityName");
            return (Criteria) this;
        }

        public Criteria andCommunityNameGreaterThan(String value) {
            addCriterion("community_name >", value, "communityName");
            return (Criteria) this;
        }

        public Criteria andCommunityNameGreaterThanOrEqualTo(String value) {
            addCriterion("community_name >=", value, "communityName");
            return (Criteria) this;
        }

        public Criteria andCommunityNameLessThan(String value) {
            addCriterion("community_name <", value, "communityName");
            return (Criteria) this;
        }

        public Criteria andCommunityNameLessThanOrEqualTo(String value) {
            addCriterion("community_name <=", value, "communityName");
            return (Criteria) this;
        }

        public Criteria andCommunityNameLike(String value) {
            addCriterion("community_name like", value, "communityName");
            return (Criteria) this;
        }

        public Criteria andCommunityNameNotLike(String value) {
            addCriterion("community_name not like", value, "communityName");
            return (Criteria) this;
        }

        public Criteria andCommunityNameIn(List<String> values) {
            addCriterion("community_name in", values, "communityName");
            return (Criteria) this;
        }

        public Criteria andCommunityNameNotIn(List<String> values) {
            addCriterion("community_name not in", values, "communityName");
            return (Criteria) this;
        }

        public Criteria andCommunityNameBetween(String value1, String value2) {
            addCriterion("community_name between", value1, value2, "communityName");
            return (Criteria) this;
        }

        public Criteria andCommunityNameNotBetween(String value1, String value2) {
            addCriterion("community_name not between", value1, value2, "communityName");
            return (Criteria) this;
        }
        
			
        public Criteria andHouseLinkmanIsNull() {
            addCriterion("house_linkman is null");
            return (Criteria) this;
        }

        public Criteria andHouseLinkmanIsNotNull() {
            addCriterion("house_linkman is not null");
            return (Criteria) this;
        }

        public Criteria andHouseLinkmanEqualTo(String value) {
            addCriterion("house_linkman =", value, "houseLinkman");
            return (Criteria) this;
        }

        public Criteria andHouseLinkmanNotEqualTo(String value) {
            addCriterion("house_linkman <>", value, "houseLinkman");
            return (Criteria) this;
        }

        public Criteria andHouseLinkmanGreaterThan(String value) {
            addCriterion("house_linkman >", value, "houseLinkman");
            return (Criteria) this;
        }

        public Criteria andHouseLinkmanGreaterThanOrEqualTo(String value) {
            addCriterion("house_linkman >=", value, "houseLinkman");
            return (Criteria) this;
        }

        public Criteria andHouseLinkmanLessThan(String value) {
            addCriterion("house_linkman <", value, "houseLinkman");
            return (Criteria) this;
        }

        public Criteria andHouseLinkmanLessThanOrEqualTo(String value) {
            addCriterion("house_linkman <=", value, "houseLinkman");
            return (Criteria) this;
        }

        public Criteria andHouseLinkmanLike(String value) {
            addCriterion("house_linkman like", value, "houseLinkman");
            return (Criteria) this;
        }

        public Criteria andHouseLinkmanNotLike(String value) {
            addCriterion("house_linkman not like", value, "houseLinkman");
            return (Criteria) this;
        }

        public Criteria andHouseLinkmanIn(List<String> values) {
            addCriterion("house_linkman in", values, "houseLinkman");
            return (Criteria) this;
        }

        public Criteria andHouseLinkmanNotIn(List<String> values) {
            addCriterion("house_linkman not in", values, "houseLinkman");
            return (Criteria) this;
        }

        public Criteria andHouseLinkmanBetween(String value1, String value2) {
            addCriterion("house_linkman between", value1, value2, "houseLinkman");
            return (Criteria) this;
        }

        public Criteria andHouseLinkmanNotBetween(String value1, String value2) {
            addCriterion("house_linkman not between", value1, value2, "houseLinkman");
            return (Criteria) this;
        }
        
			
        public Criteria andHouseOrientedIsNull() {
            addCriterion("house_oriented is null");
            return (Criteria) this;
        }

        public Criteria andHouseOrientedIsNotNull() {
            addCriterion("house_oriented is not null");
            return (Criteria) this;
        }

        public Criteria andHouseOrientedEqualTo(String value) {
            addCriterion("house_oriented =", value, "houseOriented");
            return (Criteria) this;
        }

        public Criteria andHouseOrientedNotEqualTo(String value) {
            addCriterion("house_oriented <>", value, "houseOriented");
            return (Criteria) this;
        }

        public Criteria andHouseOrientedGreaterThan(String value) {
            addCriterion("house_oriented >", value, "houseOriented");
            return (Criteria) this;
        }

        public Criteria andHouseOrientedGreaterThanOrEqualTo(String value) {
            addCriterion("house_oriented >=", value, "houseOriented");
            return (Criteria) this;
        }

        public Criteria andHouseOrientedLessThan(String value) {
            addCriterion("house_oriented <", value, "houseOriented");
            return (Criteria) this;
        }

        public Criteria andHouseOrientedLessThanOrEqualTo(String value) {
            addCriterion("house_oriented <=", value, "houseOriented");
            return (Criteria) this;
        }

        public Criteria andHouseOrientedLike(String value) {
            addCriterion("house_oriented like", value, "houseOriented");
            return (Criteria) this;
        }

        public Criteria andHouseOrientedNotLike(String value) {
            addCriterion("house_oriented not like", value, "houseOriented");
            return (Criteria) this;
        }

        public Criteria andHouseOrientedIn(List<String> values) {
            addCriterion("house_oriented in", values, "houseOriented");
            return (Criteria) this;
        }

        public Criteria andHouseOrientedNotIn(List<String> values) {
            addCriterion("house_oriented not in", values, "houseOriented");
            return (Criteria) this;
        }

        public Criteria andHouseOrientedBetween(String value1, String value2) {
            addCriterion("house_oriented between", value1, value2, "houseOriented");
            return (Criteria) this;
        }

        public Criteria andHouseOrientedNotBetween(String value1, String value2) {
            addCriterion("house_oriented not between", value1, value2, "houseOriented");
            return (Criteria) this;
        }
        
			
        public Criteria andHouseDetailesImgIsNull() {
            addCriterion("house_detailes_img is null");
            return (Criteria) this;
        }

        public Criteria andHouseDetailesImgIsNotNull() {
            addCriterion("house_detailes_img is not null");
            return (Criteria) this;
        }

        public Criteria andHouseDetailesImgEqualTo(String value) {
            addCriterion("house_detailes_img =", value, "houseDetailesImg");
            return (Criteria) this;
        }

        public Criteria andHouseDetailesImgNotEqualTo(String value) {
            addCriterion("house_detailes_img <>", value, "houseDetailesImg");
            return (Criteria) this;
        }

        public Criteria andHouseDetailesImgGreaterThan(String value) {
            addCriterion("house_detailes_img >", value, "houseDetailesImg");
            return (Criteria) this;
        }

        public Criteria andHouseDetailesImgGreaterThanOrEqualTo(String value) {
            addCriterion("house_detailes_img >=", value, "houseDetailesImg");
            return (Criteria) this;
        }

        public Criteria andHouseDetailesImgLessThan(String value) {
            addCriterion("house_detailes_img <", value, "houseDetailesImg");
            return (Criteria) this;
        }

        public Criteria andHouseDetailesImgLessThanOrEqualTo(String value) {
            addCriterion("house_detailes_img <=", value, "houseDetailesImg");
            return (Criteria) this;
        }

        public Criteria andHouseDetailesImgLike(String value) {
            addCriterion("house_detailes_img like", value, "houseDetailesImg");
            return (Criteria) this;
        }

        public Criteria andHouseDetailesImgNotLike(String value) {
            addCriterion("house_detailes_img not like", value, "houseDetailesImg");
            return (Criteria) this;
        }

        public Criteria andHouseDetailesImgIn(List<String> values) {
            addCriterion("house_detailes_img in", values, "houseDetailesImg");
            return (Criteria) this;
        }

        public Criteria andHouseDetailesImgNotIn(List<String> values) {
            addCriterion("house_detailes_img not in", values, "houseDetailesImg");
            return (Criteria) this;
        }

        public Criteria andHouseDetailesImgBetween(String value1, String value2) {
            addCriterion("house_detailes_img between", value1, value2, "houseDetailesImg");
            return (Criteria) this;
        }

        public Criteria andHouseDetailesImgNotBetween(String value1, String value2) {
            addCriterion("house_detailes_img not between", value1, value2, "houseDetailesImg");
            return (Criteria) this;
        }
        
			
        public Criteria andPublisherIsNull() {
            addCriterion("publisher is null");
            return (Criteria) this;
        }

        public Criteria andPublisherIsNotNull() {
            addCriterion("publisher is not null");
            return (Criteria) this;
        }

        public Criteria andPublisherEqualTo(String value) {
            addCriterion("publisher =", value, "publisher");
            return (Criteria) this;
        }

        public Criteria andPublisherNotEqualTo(String value) {
            addCriterion("publisher <>", value, "publisher");
            return (Criteria) this;
        }

        public Criteria andPublisherGreaterThan(String value) {
            addCriterion("publisher >", value, "publisher");
            return (Criteria) this;
        }

        public Criteria andPublisherGreaterThanOrEqualTo(String value) {
            addCriterion("publisher >=", value, "publisher");
            return (Criteria) this;
        }

        public Criteria andPublisherLessThan(String value) {
            addCriterion("publisher <", value, "publisher");
            return (Criteria) this;
        }

        public Criteria andPublisherLessThanOrEqualTo(String value) {
            addCriterion("publisher <=", value, "publisher");
            return (Criteria) this;
        }

        public Criteria andPublisherLike(String value) {
            addCriterion("publisher like", value, "publisher");
            return (Criteria) this;
        }

        public Criteria andPublisherNotLike(String value) {
            addCriterion("publisher not like", value, "publisher");
            return (Criteria) this;
        }

        public Criteria andPublisherIn(List<String> values) {
            addCriterion("publisher in", values, "publisher");
            return (Criteria) this;
        }

        public Criteria andPublisherNotIn(List<String> values) {
            addCriterion("publisher not in", values, "publisher");
            return (Criteria) this;
        }

        public Criteria andPublisherBetween(String value1, String value2) {
            addCriterion("publisher between", value1, value2, "publisher");
            return (Criteria) this;
        }

        public Criteria andPublisherNotBetween(String value1, String value2) {
            addCriterion("publisher not between", value1, value2, "publisher");
            return (Criteria) this;
        }
        
			
        public Criteria andPublishTimeIsNull() {
            addCriterion("publish_time is null");
            return (Criteria) this;
        }

        public Criteria andPublishTimeIsNotNull() {
            addCriterion("publish_time is not null");
            return (Criteria) this;
        }

        public Criteria andPublishTimeEqualTo(Date value) {
            addCriterion("publish_time =", value, "publishTime");
            return (Criteria) this;
        }

        public Criteria andPublishTimeNotEqualTo(Date value) {
            addCriterion("publish_time <>", value, "publishTime");
            return (Criteria) this;
        }

        public Criteria andPublishTimeGreaterThan(Date value) {
            addCriterion("publish_time >", value, "publishTime");
            return (Criteria) this;
        }

        public Criteria andPublishTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("publish_time >=", value, "publishTime");
            return (Criteria) this;
        }

        public Criteria andPublishTimeLessThan(Date value) {
            addCriterion("publish_time <", value, "publishTime");
            return (Criteria) this;
        }

        public Criteria andPublishTimeLessThanOrEqualTo(Date value) {
            addCriterion("publish_time <=", value, "publishTime");
            return (Criteria) this;
        }

        public Criteria andPublishTimeLike(Date value) {
            addCriterion("publish_time like", value, "publishTime");
            return (Criteria) this;
        }

        public Criteria andPublishTimeNotLike(Date value) {
            addCriterion("publish_time not like", value, "publishTime");
            return (Criteria) this;
        }

        public Criteria andPublishTimeIn(List<Date> values) {
            addCriterion("publish_time in", values, "publishTime");
            return (Criteria) this;
        }

        public Criteria andPublishTimeNotIn(List<Date> values) {
            addCriterion("publish_time not in", values, "publishTime");
            return (Criteria) this;
        }

        public Criteria andPublishTimeBetween(Date value1, Date value2) {
            addCriterion("publish_time between", value1, value2, "publishTime");
            return (Criteria) this;
        }

        public Criteria andPublishTimeNotBetween(Date value1, Date value2) {
            addCriterion("publish_time not between", value1, value2, "publishTime");
            return (Criteria) this;
        }
        
			
        public Criteria andUserIdIsNull() {
            addCriterion("user_id is null");
            return (Criteria) this;
        }

        public Criteria andUserIdIsNotNull() {
            addCriterion("user_id is not null");
            return (Criteria) this;
        }

        public Criteria andUserIdEqualTo(Integer value) {
            addCriterion("user_id =", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotEqualTo(Integer value) {
            addCriterion("user_id <>", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdGreaterThan(Integer value) {
            addCriterion("user_id >", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("user_id >=", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdLessThan(Integer value) {
            addCriterion("user_id <", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdLessThanOrEqualTo(Integer value) {
            addCriterion("user_id <=", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdLike(Integer value) {
            addCriterion("user_id like", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotLike(Integer value) {
            addCriterion("user_id not like", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdIn(List<Integer> values) {
            addCriterion("user_id in", values, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotIn(List<Integer> values) {
            addCriterion("user_id not in", values, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdBetween(Integer value1, Integer value2) {
            addCriterion("user_id between", value1, value2, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotBetween(Integer value1, Integer value2) {
            addCriterion("user_id not between", value1, value2, "userId");
            return (Criteria) this;
        }
        
			
        public Criteria andStatusIsNull() {
            addCriterion("status is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("status is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(Integer value) {
            addCriterion("status =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(Integer value) {
            addCriterion("status <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(Integer value) {
            addCriterion("status >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("status >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(Integer value) {
            addCriterion("status <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(Integer value) {
            addCriterion("status <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLike(Integer value) {
            addCriterion("status like", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotLike(Integer value) {
            addCriterion("status not like", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<Integer> values) {
            addCriterion("status in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<Integer> values) {
            addCriterion("status not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(Integer value1, Integer value2) {
            addCriterion("status between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("status not between", value1, value2, "status");
            return (Criteria) this;
        }
        
			
        public Criteria andStatusStrIsNull() {
            addCriterion("status_str is null");
            return (Criteria) this;
        }

        public Criteria andStatusStrIsNotNull() {
            addCriterion("status_str is not null");
            return (Criteria) this;
        }

        public Criteria andStatusStrEqualTo(String value) {
            addCriterion("status_str =", value, "statusStr");
            return (Criteria) this;
        }

        public Criteria andStatusStrNotEqualTo(String value) {
            addCriterion("status_str <>", value, "statusStr");
            return (Criteria) this;
        }

        public Criteria andStatusStrGreaterThan(String value) {
            addCriterion("status_str >", value, "statusStr");
            return (Criteria) this;
        }

        public Criteria andStatusStrGreaterThanOrEqualTo(String value) {
            addCriterion("status_str >=", value, "statusStr");
            return (Criteria) this;
        }

        public Criteria andStatusStrLessThan(String value) {
            addCriterion("status_str <", value, "statusStr");
            return (Criteria) this;
        }

        public Criteria andStatusStrLessThanOrEqualTo(String value) {
            addCriterion("status_str <=", value, "statusStr");
            return (Criteria) this;
        }

        public Criteria andStatusStrLike(String value) {
            addCriterion("status_str like", value, "statusStr");
            return (Criteria) this;
        }

        public Criteria andStatusStrNotLike(String value) {
            addCriterion("status_str not like", value, "statusStr");
            return (Criteria) this;
        }

        public Criteria andStatusStrIn(List<String> values) {
            addCriterion("status_str in", values, "statusStr");
            return (Criteria) this;
        }

        public Criteria andStatusStrNotIn(List<String> values) {
            addCriterion("status_str not in", values, "statusStr");
            return (Criteria) this;
        }

        public Criteria andStatusStrBetween(String value1, String value2) {
            addCriterion("status_str between", value1, value2, "statusStr");
            return (Criteria) this;
        }

        public Criteria andStatusStrNotBetween(String value1, String value2) {
            addCriterion("status_str not between", value1, value2, "statusStr");
            return (Criteria) this;
        }
        
	}

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}