package com.fc.test.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

import com.fc.test.mapper.auto.SysHouseMapper;
import com.fc.test.model.auto.SysHouse;
import com.fc.test.model.auto.TsysUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.fc.test.common.base.BaseService;
import com.fc.test.common.support.Convert;
import com.fc.test.mapper.auto.SysMyhouseMapper;
import com.fc.test.model.auto.SysMyhouse;
import com.fc.test.model.auto.SysMyhouseExample;
import com.fc.test.model.custom.Tablepar;
import com.fc.test.util.SnowflakeIdWorker;

/**
 *  SysMyhouseService
 * @Title: SysMyhouseService.java 
 * @Package com.fc.test.service 
 * @author wcy_自动生成
 * @email xxx@qq.com
 * @date 2020-03-16 21:30:57  
 **/
@Service
public class SysMyhouseService implements BaseService<SysMyhouse, SysMyhouseExample>{
	@Autowired
	private SysMyhouseMapper sysMyhouseMapper;
	@Autowired
    private SysHouseMapper houseMapper;
	@Autowired
    private SysUserService sysUserService;
	
      	   	      	      	      	      	      	      	
	/**
	 * 分页查询
	 * @param pageNum
	 * @param pageSize
	 * @return
	 */
	 public PageInfo<SysHouse> list(Tablepar tablepar,String name){
	        SysMyhouseExample testExample=new SysMyhouseExample();
	        testExample.setOrderByClause("id ASC");
	        if(name!=null&&!"".equals(name)){
	        	testExample.createCriteria().andIdLike(Integer.valueOf("%"+name+"%"));
	        }

	        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
	        List<SysMyhouse> list= sysMyhouseMapper.selectByExample(testExample);
            List<SysHouse> houselist= new ArrayList<>();
            list.forEach(line->{
             SysHouse house = houseMapper.selectByPrimaryKey(line.getHouseId());
             house.setPublishTime(line.getCreateDate());
             house.setHousePrice(line.getPrice().intValue());
             TsysUser user = sysUserService.selectByPrimaryKey(String.valueOf(line.getUserId()));
             house.setStatus(line.getStatus());
             house.setPublisher(user.getNickname());
             house.setId(line.getId());
             houselist.add(house);
         });
         PageInfo<SysHouse> pageInfo = new PageInfo<SysHouse>(houselist);
         return  pageInfo;
	 }

	@Override
	public int deleteByPrimaryKey(String ids) {
					
			Integer[] integers = Convert.toIntArray(",", ids);
			List<Integer> stringB = Arrays.asList(integers);
			SysMyhouseExample example=new SysMyhouseExample();
			example.createCriteria().andIdIn(stringB);
			return sysMyhouseMapper.deleteByExample(example);
			
				
	}
	
	
	@Override
	public SysMyhouse selectByPrimaryKey(String id) {
				
			Integer id1 = Integer.valueOf(id);
			return sysMyhouseMapper.selectByPrimaryKey(id1);
				
	}

	
	@Override
	public int updateByPrimaryKeySelective(SysMyhouse record) {
		return sysMyhouseMapper.updateByPrimaryKeySelective(record);
	}
	
	
	/**
	 * 添加
	 */
	@Override
	public int insertSelective(SysMyhouse record) {
				
		record.setId(null);
		
				
		return sysMyhouseMapper.insertSelective(record);
	}
	
	
	@Override
	public int updateByExampleSelective(SysMyhouse record, SysMyhouseExample example) {
		
		return sysMyhouseMapper.updateByExampleSelective(record, example);
	}

	
	@Override
	public int updateByExample(SysMyhouse record, SysMyhouseExample example) {
		
		return sysMyhouseMapper.updateByExample(record, example);
	}

	@Override
	public List<SysMyhouse> selectByExample(SysMyhouseExample example) {
		
		return sysMyhouseMapper.selectByExample(example);
	}

	
	@Override
	public long countByExample(SysMyhouseExample example) {
		
		return sysMyhouseMapper.countByExample(example);
	}

	
	@Override
	public int deleteByExample(SysMyhouseExample example) {
		
		return sysMyhouseMapper.deleteByExample(example);
	}
	
	/**
	 * 检查name
	 * @param sysMyhouse
	 * @return
	 */
	public int checkNameUnique(SysMyhouse sysMyhouse){
		SysMyhouseExample example=new SysMyhouseExample();
		example.createCriteria().andUserIdEqualTo(sysMyhouse.getUserId());
		List<SysMyhouse> list=sysMyhouseMapper.selectByExample(example);
		return list.size();
	}


}
