package com.fc.test.model.auto;

import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.lang.Integer;

/**
 * 合同信息表 SysContract 
 * @author wcy_自动生成
 * @email xxx@qq.com
 * @date 2020-03-16 21:31:11
 */
 @ApiModel(value="SysContract", description="合同信息表")
public class SysContract implements Serializable {

	private static final long serialVersionUID = 1L;
	
		
	/**  **/
	@ApiModelProperty(value = "")
	private Integer id;
		
	/** 合同编号 **/
	@ApiModelProperty(value = "合同编号")
	private String code;
		
	/** 合同内容 **/
	@ApiModelProperty(value = "合同内容")
	private String content;
		
	/** 签订日期 **/
	@ApiModelProperty(value = "签订日期")
	private String createDate;
		
	/** 房屋id **/
	@ApiModelProperty(value = "房屋id")
	private Integer hId;
		
	/** 合同状态 **/
	@ApiModelProperty(value = "合同状态")
	private Integer status;
		
	/** 客户姓名 **/
	@ApiModelProperty(value = "客户姓名")
	private String customer;
		
	/** 公司名称 **/
	@ApiModelProperty(value = "公司名称")
	private String company;
		
	/** 业主id **/
	@ApiModelProperty(value = "业主id")
	private Integer userId;
		
		
	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
	 
			
	public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
	 
			
	public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
	 
			
	public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }
	 
			
	public Integer gethId() {
        return hId;
    }

    public void sethId(Integer hId) {
        this.hId = hId;
    }
	 
			
	public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
	 
			
	public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }
	 
			
	public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }
	 
			
	public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }
	 
			
	public SysContract() {
        super();
    }
    
																																															
	public SysContract(Integer id,String code,String content,String createDate,Integer hId,Integer status,String customer,String company,Integer userId) {
	
		this.id = id;
		this.code = code;
		this.content = content;
		this.createDate = createDate;
		this.hId = hId;
		this.status = status;
		this.customer = customer;
		this.company = company;
		this.userId = userId;
		
	}
	
}