package com.fc.test.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

import com.fc.test.mapper.auto.SysMyhouseMapper;
import com.fc.test.model.auto.SysMyhouse;
import com.fc.test.model.auto.SysMyhouseExample;
import com.fc.test.shiro.util.ShiroUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.fc.test.common.base.BaseService;
import com.fc.test.common.support.Convert;
import com.fc.test.mapper.auto.SysHouseMapper;
import com.fc.test.model.auto.SysHouse;
import com.fc.test.model.auto.SysHouseExample;
import com.fc.test.model.custom.Tablepar;
import com.fc.test.util.SnowflakeIdWorker;

/**
 *  SysHouseService
 * @Title: SysHouseService.java 
 * @Package com.fc.test.service 
 * @author wcy_自动生成
 * @email xxx@qq.com
 * @date 2020-03-16 20:42:26  
 **/
@Service
public class SysHouseService implements BaseService<SysHouse, SysHouseExample>{
	@Autowired
	private SysHouseMapper sysHouseMapper;
	@Autowired
    private SysMyhouseMapper myhouseMapper;
      	   	      	      	      	      	      	      	      	      	      	      	      	      	      	      	      	      	      	      	
	/**
	 * 分页查询
	 * @param pageNum
	 * @param pageSize
	 * @return
	 */
	 public PageInfo<SysHouse> list(Tablepar tablepar,String name){
	        SysHouseExample testExample=new SysHouseExample();
	        testExample.setOrderByClause("id ASC");
	        if(name!=null&&!"".equals(name)){
	        	testExample.createCriteria().andHouseDescLike("%"+name+"%");
	        }

	        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
	        List<SysHouse> list= sysHouseMapper.selectByExample(testExample);
	        PageInfo<SysHouse> pageInfo = new PageInfo<SysHouse>(list);
	        return  pageInfo;
	 }
    public PageInfo<SysHouse> buylist(Tablepar tablepar,String name){
        SysHouseExample testExample=new SysHouseExample();
        testExample.setOrderByClause("id ASC");
        if(name!=null&&!"".equals(name)){
            testExample.createCriteria().andHouseDescLike("%"+name+"%");
        }
        //获取未出售的
        testExample.createCriteria().andStatusEqualTo(1);

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<SysHouse> list= sysHouseMapper.selectByExample(testExample);
        PageInfo<SysHouse> pageInfo = new PageInfo<SysHouse>(list);
        return  pageInfo;
    }
    public PageInfo<SysHouse> bulklist(Tablepar tablepar,String name){
        SysHouseExample testExample=new SysHouseExample();
        testExample.setOrderByClause("id ASC");
        if(name!=null&&!"".equals(name)){
            testExample.createCriteria().andHouseDescLike("%"+name+"%");
        }
        //获取未出售的
        testExample.createCriteria().andStatusEqualTo(1);

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<SysHouse> list= sysHouseMapper.selectByExample(testExample);
        list.forEach(line->{
            line.setHousePrice((int) (line.getHousePrice()*0.8));
        });
        PageInfo<SysHouse> pageInfo = new PageInfo<SysHouse>(list);
        return  pageInfo;
    }
    public PageInfo<SysHouse> mylist(Tablepar tablepar,String name){
        SysMyhouseExample testExample=new SysMyhouseExample();
//        SysHouseExample testExample=new SysHouseExample();
        testExample.setOrderByClause("id ASC");
//        if(name!=null&&!"".equals(name)){
//            testExample.createCriteria().andHouseDescLike("%"+name+"%");
//        }

        testExample.createCriteria().andUserIdEqualTo(Integer.valueOf(ShiroUtils.getUserId()));
        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<SysHouse> list= new ArrayList<>();
        List<SysMyhouse> mylist = myhouseMapper.selectByExample(testExample);
        mylist.forEach(line->{
//            SysHouse house = new SysHouse();
            SysHouse house = sysHouseMapper.selectByPrimaryKey(line.getHouseId());
            house.setPublishTime(line.getCreateDate());
            house.setHousePrice(line.getPrice().intValue());
            list.add(house);
        });
        PageInfo<SysHouse> pageInfo = new PageInfo<SysHouse>(list);
        return  pageInfo;
    }

	@Override
	public int deleteByPrimaryKey(String ids) {
					
			Integer[] integers = Convert.toIntArray(",", ids);
			List<Integer> stringB = Arrays.asList(integers);
			SysHouseExample example=new SysHouseExample();
			example.createCriteria().andIdIn(stringB);
			return sysHouseMapper.deleteByExample(example);
			
				
	}
	
	
	@Override
	public SysHouse selectByPrimaryKey(String id) {
				
			Integer id1 = Integer.valueOf(id);
			return sysHouseMapper.selectByPrimaryKey(id1);
				
	}

	
	@Override
	public int updateByPrimaryKeySelective(SysHouse record) {
		return sysHouseMapper.updateByPrimaryKeySelective(record);
	}
	
	
	/**
	 * 添加
	 */
	@Override
	public int insertSelective(SysHouse record) {
				
		record.setId(null);
		
				
		return sysHouseMapper.insertSelective(record);
	}
	
	
	@Override
	public int updateByExampleSelective(SysHouse record, SysHouseExample example) {
		
		return sysHouseMapper.updateByExampleSelective(record, example);
	}

	
	@Override
	public int updateByExample(SysHouse record, SysHouseExample example) {
		
		return sysHouseMapper.updateByExample(record, example);
	}

	@Override
	public List<SysHouse> selectByExample(SysHouseExample example) {
		
		return sysHouseMapper.selectByExample(example);
	}

	
	@Override
	public long countByExample(SysHouseExample example) {
		
		return sysHouseMapper.countByExample(example);
	}

	
	@Override
	public int deleteByExample(SysHouseExample example) {
		
		return sysHouseMapper.deleteByExample(example);
	}
	
	/**
	 * 检查name
	 * @param sysHouse
	 * @return
	 */
	public int checkNameUnique(SysHouse sysHouse){
		SysHouseExample example=new SysHouseExample();
		example.createCriteria().andHouseDescEqualTo(sysHouse.getHouseDesc());
		List<SysHouse> list=sysHouseMapper.selectByExample(example);
		return list.size();
	}


}
