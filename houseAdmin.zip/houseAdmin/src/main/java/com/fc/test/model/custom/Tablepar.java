package com.fc.test.model.custom;

/**
 * boostrap table post 参数
 * @author fc
 *
 */
public class Tablepar {
	private int pageNum;//页码
	private int pageSize;//数量
	public int getPageNum() {
		return pageNum;
	}
	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	
}
