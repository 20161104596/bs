package com.fc.test.mapper.auto;

import com.fc.test.model.auto.SysContract;
import com.fc.test.model.auto.SysContractExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * 合同信息表 SysContractMapper
 * @author wcy_自动生成
 * @email xxx@qq.com
 * @date 2020-03-16 21:31:11
 */
public interface SysContractMapper {
      	   	      	      	      	      	      	      	      	      	      
    long countByExample(SysContractExample example);

    int deleteByExample(SysContractExample example);
		
    int deleteByPrimaryKey(Integer id);
		
    int insert(SysContract record);

    int insertSelective(SysContract record);

    List<SysContract> selectByExample(SysContractExample example);
		
    SysContract selectByPrimaryKey(Integer id);
		
    int updateByExampleSelective(@Param("record") SysContract record, @Param("example") SysContractExample example);

    int updateByExample(@Param("record") SysContract record, @Param("example") SysContractExample example); 
		
    int updateByPrimaryKeySelective(SysContract record);

    int updateByPrimaryKey(SysContract record);
  	  	
}