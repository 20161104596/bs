package com.fc.test.mapper.auto;

import com.fc.test.model.auto.SysMyhouse;
import com.fc.test.model.auto.SysMyhouseExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 *  SysMyhouseMapper
 * @author wcy_自动生成
 * @email xxx@qq.com
 * @date 2020-03-16 21:30:57
 */
public interface SysMyhouseMapper {
      	   	      	      	      	      	      	      
    long countByExample(SysMyhouseExample example);

    int deleteByExample(SysMyhouseExample example);
		
    int deleteByPrimaryKey(Integer id);
		
    int insert(SysMyhouse record);

    int insertSelective(SysMyhouse record);

    List<SysMyhouse> selectByExample(SysMyhouseExample example);
		
    SysMyhouse selectByPrimaryKey(Integer id);
		
    int updateByExampleSelective(@Param("record") SysMyhouse record, @Param("example") SysMyhouseExample example);

    int updateByExample(@Param("record") SysMyhouse record, @Param("example") SysMyhouseExample example); 
		
    int updateByPrimaryKeySelective(SysMyhouse record);

    int updateByPrimaryKey(SysMyhouse record);
  	  	
}