package com.fc.test.service;

import java.util.List;
import java.util.Arrays;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.fc.test.common.base.BaseService;
import com.fc.test.common.support.Convert;
import com.fc.test.mapper.auto.SysContractMapper;
import com.fc.test.model.auto.SysContract;
import com.fc.test.model.auto.SysContractExample;
import com.fc.test.model.custom.Tablepar;
import com.fc.test.util.SnowflakeIdWorker;

/**
 * 合同信息表 SysContractService
 * @Title: SysContractService.java 
 * @Package com.fc.test.service 
 * @author wcy_自动生成
 * @email xxx@qq.com
 * @date 2020-03-16 21:31:11  
 **/
@Service
public class SysContractService implements BaseService<SysContract, SysContractExample>{
	@Autowired
	private SysContractMapper sysContractMapper;
	
      	   	      	      	      	      	      	      	      	      	      	
	/**
	 * 分页查询
	 * @param pageNum
	 * @param pageSize
	 * @return
	 */
	 public PageInfo<SysContract> list(Tablepar tablepar,String name){
	        SysContractExample testExample=new SysContractExample();
	        testExample.setOrderByClause("id ASC");
	        if(name!=null&&!"".equals(name)){
	        	testExample.createCriteria().andCodeLike("%"+name+"%");
	        }

	        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
	        List<SysContract> list= sysContractMapper.selectByExample(testExample);
	        PageInfo<SysContract> pageInfo = new PageInfo<SysContract>(list);
	        return  pageInfo;
	 }

	@Override
	public int deleteByPrimaryKey(String ids) {
					
			Integer[] integers = Convert.toIntArray(",", ids);
			List<Integer> stringB = Arrays.asList(integers);
			SysContractExample example=new SysContractExample();
			example.createCriteria().andIdIn(stringB);
			return sysContractMapper.deleteByExample(example);
			
				
	}
	
	
	@Override
	public SysContract selectByPrimaryKey(String id) {
				
			Integer id1 = Integer.valueOf(id);
			return sysContractMapper.selectByPrimaryKey(id1);
				
	}

	
	@Override
	public int updateByPrimaryKeySelective(SysContract record) {
		return sysContractMapper.updateByPrimaryKeySelective(record);
	}
	
	
	/**
	 * 添加
	 */
	@Override
	public int insertSelective(SysContract record) {
				
		record.setId(null);
		
				
		return sysContractMapper.insertSelective(record);
	}
	
	
	@Override
	public int updateByExampleSelective(SysContract record, SysContractExample example) {
		
		return sysContractMapper.updateByExampleSelective(record, example);
	}

	
	@Override
	public int updateByExample(SysContract record, SysContractExample example) {
		
		return sysContractMapper.updateByExample(record, example);
	}

	@Override
	public List<SysContract> selectByExample(SysContractExample example) {
		
		return sysContractMapper.selectByExample(example);
	}

	
	@Override
	public long countByExample(SysContractExample example) {
		
		return sysContractMapper.countByExample(example);
	}

	
	@Override
	public int deleteByExample(SysContractExample example) {
		
		return sysContractMapper.deleteByExample(example);
	}
	
	/**
	 * 检查name
	 * @param sysContract
	 * @return
	 */
	public int checkNameUnique(SysContract sysContract){
		SysContractExample example=new SysContractExample();
		example.createCriteria().andCodeEqualTo(sysContract.getCode());
		List<SysContract> list=sysContractMapper.selectByExample(example);
		return list.size();
	}


}
