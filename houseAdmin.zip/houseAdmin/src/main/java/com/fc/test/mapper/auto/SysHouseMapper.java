package com.fc.test.mapper.auto;

import com.fc.test.model.auto.SysHouse;
import com.fc.test.model.auto.SysHouseExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 *  SysHouseMapper
 * @author wcy_自动生成
 * @email xxx@qq.com
 * @date 2020-03-16 20:42:26
 */
public interface SysHouseMapper {
      	   	      	      	      	      	      	      	      	      	      	      	      	      	      	      	      	      	      	      
    long countByExample(SysHouseExample example);

    int deleteByExample(SysHouseExample example);
		
    int deleteByPrimaryKey(Integer id);
		
    int insert(SysHouse record);

    int insertSelective(SysHouse record);

    List<SysHouse> selectByExample(SysHouseExample example);
		
    SysHouse selectByPrimaryKey(Integer id);
		
    int updateByExampleSelective(@Param("record") SysHouse record, @Param("example") SysHouseExample example);

    int updateByExample(@Param("record") SysHouse record, @Param("example") SysHouseExample example); 
		
    int updateByPrimaryKeySelective(SysHouse record);

    int updateByPrimaryKey(SysHouse record);
  	  	
}