package com.fc.test.model.auto;

import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.lang.Integer;

/**
 *  SysMyhouse 
 * @author wcy_自动生成
 * @email xxx@qq.com
 * @date 2020-03-16 21:30:57
 */
 @ApiModel(value="SysMyhouse", description="")
public class SysMyhouse implements Serializable {

	private static final long serialVersionUID = 1L;
	
		
	/**  **/
	@ApiModelProperty(value = "")
	private Integer id;
		
	/**  **/
	@ApiModelProperty(value = "")
	private Integer userId;
		
	/**  **/
	@ApiModelProperty(value = "")
	private Integer houseId;
		
	/**  **/
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
	@ApiModelProperty(value = "")
	private Date createDate;
		
	/**  **/
	@ApiModelProperty(value = "")
	private Integer status;
		
	/**  **/
	@ApiModelProperty(value = "")
	private BigDecimal price;
		
		
	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
	 
			
	public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }
	 
			
	public Integer getHouseId() {
        return houseId;
    }

    public void setHouseId(Integer houseId) {
        this.houseId = houseId;
    }
	 
			
	public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
	 
			
	public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
	 
			
	public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }
	 
			
	public SysMyhouse() {
        super();
    }
    
																																
	public SysMyhouse(Integer id,Integer userId,Integer houseId,Date createDate,Integer status,BigDecimal price) {
	
		this.id = id;
		this.userId = userId;
		this.houseId = houseId;
		this.createDate = createDate;
		this.status = status;
		this.price = price;
		
	}
	
}