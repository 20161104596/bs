//控制右边高度得js
//function reinitIframe(){
//		var $parent =window.parent.document.getElementById("mainFrame");
//		$($parent).attr("height",document.body.scrollHeight);
//		
//	}
//window.setInterval("reinitIframe()", 200);